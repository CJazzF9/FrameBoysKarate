export default function Home() {
  return (
    <main>
      <h1>Welcome to Frame Brothers Karate</h1>
      <p>This is the placeholder homepage.</p>
    </main>
  );
}
