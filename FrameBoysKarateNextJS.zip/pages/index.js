export default function Home() {
  return (
    <main>
      <h1>Welcome to Frame Brothers Karate</h1>
      <p>Representing Team USA on the road to the World Championship in Germany.</p>
    </main>
  );
}
